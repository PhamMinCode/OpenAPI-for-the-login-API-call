describe("Testing the test environment", () => {
    it("Tests our testing framework", () => {
        expect(2).toBe(2)
    });   
});